# Real-Time Chat Application using Django Channels.

Developed a real-time chat application using Django and Channels. The design is made using Tailwind CSS.

## Features
1.Rooms or Group Chat
2.User Authentication
3.Security
4.ChatBot
5.Dark/Light Mode
6.Responsiveness
7.Interactive GUI
8.Contact Us 
9.Description of Room

## Author
This repository is created by Sarthak Joshi.


